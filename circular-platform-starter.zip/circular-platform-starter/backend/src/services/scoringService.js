export function computeSoilIndex(sample) {
  // sample: { pH, organicMatterPercent, heavyMetals: {...}, nitrates }
  let score = 100;
  if (!sample) return 0;
  if (sample.pH < 5 || sample.pH > 8) score -= 20;
  if (sample.organicMatterPercent !== undefined) score -= Math.max(0, (7 - sample.organicMatterPercent) * 2);
  if (sample.heavyMetals) {
    Object.values(sample.heavyMetals).forEach(v => {
      if (v > 0.1) score -= 15;
    });
  }
  return Math.max(0, Math.round(score));
}
