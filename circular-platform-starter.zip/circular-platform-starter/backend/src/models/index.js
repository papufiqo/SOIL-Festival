import { Sequelize, DataTypes } from 'sequelize';
import dotenv from 'dotenv';
dotenv.config();

const sequelize = new Sequelize(process.env.PG_DATABASE || 'circular', process.env.PG_USER || 'postgres', process.env.PG_PASSWORD || 'postgres', {
  host: process.env.PG_HOST || 'db',
  port: process.env.PG_PORT || 5432,
  dialect: 'postgres',
  logging: false
});

export const Material = sequelize.define('Material', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING },
  composition: { type: DataTypes.JSONB, defaultValue: {} },
  recyclabilityScore: { type: DataTypes.INTEGER, defaultValue: 0 },
  batchId: { type: DataTypes.STRING },
  certificates: { type: DataTypes.JSONB, defaultValue: [] }
}, { timestamps: true });

export const MaterialEvent = sequelize.define('MaterialEvent', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  materialId: { type: DataTypes.UUID, allowNull: false },
  timestamp: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  actorId: { type: DataTypes.STRING },
  eventType: { type: DataTypes.STRING },
  location: { type: DataTypes.JSONB },
  meta: { type: DataTypes.JSONB }
}, { timestamps: false });

export const SoilSample = sequelize.define('SoilSample', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  geohash: { type: DataTypes.STRING },
  sampleDate: { type: DataTypes.DATE },
  pH: { type: DataTypes.FLOAT },
  organicMatterPercent: { type: DataTypes.FLOAT },
  heavyMetals: { type: DataTypes.JSONB },
  score: { type: DataTypes.INTEGER }
}, { timestamps: true });

export const NTNSession = sequelize.define('NTNSession', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  deviceId: { type: DataTypes.STRING },
  ownerId: { type: DataTypes.STRING },
  sliceId: { type: DataTypes.STRING },
  qos: { type: DataTypes.JSONB }
}, { timestamps: true });

export async function initDb() {
  await sequelize.authenticate();
  await sequelize.sync();
  console.log('Sequelize: DB connected and synced');
}
