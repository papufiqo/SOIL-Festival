import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';
import materialsRouter from './routes/materials.js';
import ntnRouter from './routes/ntn.js';
import { initDb, SoilSample } from './models/index.js';
import mqtt from 'mqtt';

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// API routers
app.use('/api/v1/materials', materialsRouter);
app.use('/api/v1/ntn', ntnRouter);

app.get('/api/v1/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;

async function start() {
  try {
    await initDb();
  } catch (err) {
    console.warn('DB init failed (continuing in degraded mode):', err.message || err);
  }

  app.listen(PORT, () => console.log(`API listening on ${PORT}`));

  // Connect to MQTT and ingest soil sensor messages
  const mqttUrl = process.env.MQTT_URL || 'mqtt://mqtt:1883';
  const client = mqtt.connect(mqttUrl);
  client.on('connect', () => {
    console.log('Connected to MQTT broker at', mqttUrl);
    client.subscribe('sensors/+/data', (err) => {
      if (err) console.warn('Failed to subscribe to sensors topic', err);
    });
  });

  client.on('message', async (topic, message) => {
    try {
      const payload = JSON.parse(message.toString());
      console.log('MQTT message', topic, payload);
      if (SoilSample) {
        await SoilSample.create({
          geohash: payload.geohash || null,
          sampleDate: payload.timestamp || new Date(),
          pH: payload.pH || null,
          organicMatterPercent: payload.organicMatterPercent || null,
          heavyMetals: payload.heavyMetals || {},
          score: null
        });
        console.log('Soil sample saved to DB');
      }
    } catch (e) {
      console.error('Error processing MQTT message:', e.message || e);
    }
  });
}

start();
