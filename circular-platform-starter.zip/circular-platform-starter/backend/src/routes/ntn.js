import { Router } from 'express';
import { NTNSession } from '../models/index.js';

const router = Router();

// Simulated E2-like session establishment for NTN devices
router.post('/session', async (req, res) => {
  const { deviceId, owner, qos } = req.body;
  const session = await NTNSession.create({
    deviceId,
    ownerId: owner,
    sliceId: `slice_${Date.now()}`,
    qos: qos || { ul: '64kbps', priority: 'standard' }
  });
  res.status(201).json(session);
});

// Request a network slice (stub - operator integration required in production)
router.post('/slice-request', (req, res) => {
  const { tenantId, sliceProfile } = req.body;
  const slice = { id: `slice_${Date.now()}`, tenantId, profile: sliceProfile, status: 'requested' };
  res.status(201).json(slice);
});

// List active slices (mock)
router.get('/slices', (req, res) => {
  res.json([{ id: 'slice_demo_1', tenantId: 'demo', profile: { qos: 'telemetry-high' }, status: 'active' }]);
});

export default router;
