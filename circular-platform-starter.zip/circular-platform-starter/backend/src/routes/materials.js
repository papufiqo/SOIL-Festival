import { Router } from 'express';
import { Material, MaterialEvent } from '../models/index.js';

const router = Router();

// List materials
router.get('/', async (req, res) => {
  const items = await Material.findAll();
  res.json(items);
});

// Create material
router.post('/', async (req, res) => {
  const body = req.body;
  const m = await Material.create(body);
  res.status(201).json(m);
});

// Get material by id
router.get('/:id', async (req, res) => {
  const m = await Material.findByPk(req.params.id);
  if (!m) return res.status(404).json({ error: 'Material not found' });
  res.json(m);
});

// Append lifecycle event to a material
router.post('/:id/events', async (req, res) => {
  const ev = req.body;
  ev.materialId = req.params.id;
  const e = await MaterialEvent.create(ev);
  res.status(201).json(e);
});

export default router;
