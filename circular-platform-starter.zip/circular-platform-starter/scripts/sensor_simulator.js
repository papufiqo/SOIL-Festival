/**
 * Simple MQTT sensor simulator that publishes soil sensor messages every few seconds.
 * Usage: `node scripts/sensor_simulator.js`
 */
import mqtt from 'mqtt';
import dotenv from 'dotenv';
dotenv.config();

const mqttUrl = process.env.MQTT_URL || 'mqtt://localhost:1883';
const client = mqtt.connect(mqttUrl);

client.on('connect', () => {
  console.log('Connected to MQTT at', mqttUrl);
  setInterval(() => {
    const payload = {
      deviceId: 'sensor_demo_1',
      timestamp: new Date().toISOString(),
      pH: (5.5 + Math.random() * 2.0).toFixed(2),
      soilMoisture: Math.round(Math.random() * 100),
      organicMatterPercent: (2 + Math.random() * 6).toFixed(2)
    };
    client.publish('sensors/sensor_demo_1/data', JSON.stringify(payload));
    console.log('Published sensor payload', payload);
  }, 5000);
});
