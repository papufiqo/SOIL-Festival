# Circular Platform — Starter (IoT sensing + Industrial Symbiosis)

This starter repository contains a minimal working backend that:
- exposes REST APIs for materials, NTN/session, and soil samples
- connects to a Postgres DB (via Docker Compose)
- connects to an MQTT broker and ingests simulated soil sensor messages
- serves a tiny static dashboard `public/index.html` for quick viewing

## Quick-start (local)

1. Install Docker & Docker Compose, Node.js (>=18) and Git.
2. Copy `.env.example` to `.env` and adjust if needed.
3. Run `docker-compose up --build -d` to start DB + MQTT + backend (backend built from `backend/`).
4. Install backend deps (if running locally without Docker): `cd backend && npm ci`
5. Start backend (if not using Docker build): `npm run dev` inside `backend/`
6. Open `http://localhost:4000` to see the tiny dashboard and `http://localhost:4000/api/v1/health` for health.

## Files included (key)
- `docker-compose.yml` – postgres, mosquitto (mqtt), backend service
- `backend/` – Node.js + Express backend, Sequelize models, MQTT ingestion
- `scripts/sensor_simulator.js` – Node script that publishes MQTT sensor data (run with `node scripts/sensor_simulator.js`)
- `.env.example` – example environment variables
- `.gitignore`

Push to your GitHub repo with standard `git` commands after review.
